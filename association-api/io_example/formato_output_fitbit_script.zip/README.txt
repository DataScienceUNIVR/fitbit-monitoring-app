questa cartella contiene informazioni riguardanti l'output dello script di ricerca di regole di associazione nel progeto fitbit.

Il file "output.json" è un esempio del risultato di un'esecuzione dello script e contiene una lista di elementi json, prima di essere scritto su file, su ogni elemento json viene eseguito un parsing con la funzione json.loads()

Il file "template.txt" contiene il formato di un singolo elemento json

Il file "single_element_example.txt" contiene un esempio di un elemento json (su cui è stato utilizzato un json formatter per facilitarne la lettura) 
